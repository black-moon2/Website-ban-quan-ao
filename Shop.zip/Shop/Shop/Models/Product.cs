﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shop.Models
{
    [Table("Product")]
    public class Product
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ProductID { get; set; }

        public string? Title { get; set; }

        public int? ProductCategoryID { get; set; }

        public string? Description { get; set; }

        public string? Detail { get; set; }

        public string? Image { get; set; }

        public decimal? Price { get; set; }

        public decimal? PriceSale { get; set; }

        public int? Quantity { get; set; }
        public string? SeoTitle { get; set; }
        public string? SeoDescription { get; set; }
        public string? SeoKeywords { get; set; }

        public DateTime? CreatedDate { get; set; }
        
        public string? CreatedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public string? ModifiedBy { get; set; }
        public bool? IsHome { get; set; }
        public bool? IsHot { get; set; }
        public bool? IsSale { get; set; }
        public bool? IsFeature { get; set; }
        public virtual ProductCategory? ProductCategorys { get; set; }
        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}
