﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shop.Models
{
    [Table("System_Setting")]
    public class System_Setting
    {

        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int SettingId { get; set; }

        public string? SettingKey { get; set; }

        public string? SettingValue { get; set; }

        public string? SettingDescription { get; set; }
    }
}
