﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shop.Models
{
    [Table("OrderDetail")]
    public class OrderDetail
    {
        [Key]
        public int OrderDetailID {  get; set; }
        public int? OrderID { get; set; }
        public int? ProductID { get; set; }

        public decimal? Price { get; set; }
        public int? Quantity { get; set; }
        public virtual Order? Orders { get; set; }
        public virtual Product? Products { get; set; }    
    }
}
