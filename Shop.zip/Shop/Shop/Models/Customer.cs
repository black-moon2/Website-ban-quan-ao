﻿using Microsoft.CodeAnalysis;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shop.Models
{
    [Table("Customer")]
    public class Customer
    {
        [Key]
        public int CustomerID { get; set; }

        public string? FullName { get; set; }

        public string? Password { get; set; }

        public DateTime? Birthday { get; set; }

        public string? Phone { get; set; }

        public string? Email { get; set; }

        public int? LocationID { get; set; }

        public DateTime? LastLogin { get; set; }

        public bool IsActive { get; set; }

        public virtual Location? Location { get; set; }
    }
}
