﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shop.Models
{
    [Table("ProductImage")]
    public class ProductImages
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ProductImageID { get; set; }
        public int? ProductID { get; set; }
        public string? Image {  get; set; }
        public bool? IsDefault { get; set; }
    }
}
