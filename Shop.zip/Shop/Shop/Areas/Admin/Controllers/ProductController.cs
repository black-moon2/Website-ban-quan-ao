﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Shop.Models;

namespace Shop.Areas.Admin.Controllers
{
	[Area("Admin")]
	public class ProductController : Controller
	{
		private readonly DataContext _context;
		public ProductController(DataContext context)
		{
			_context = context;
		}
		// hiển thị san p
		public IActionResult Index()
		{
			var mnProduct = _context.Products.OrderBy(p => p.ProductID).ToList();
			return View(mnProduct);
			
		}
		// tao sản pahm
		public IActionResult Create()
		{
			return View();
		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Create(Product product)
		{
			if (ModelState.IsValid)
			{
				_context.Products.Add(product);
				_context.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(product);
		}
		// xóa
		public IActionResult Delete(int? id)
		{
			if (id == null || id == 0)
			{
				return NotFound();
			}

			var product = _context.Products.Find(id);
			if (product == null)
			{
				return NotFound();
			}
			return View(product);
		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Delete(int id)
		{
			var product = _context.Products.Find(id);
			if (product == null)
			{
				return NotFound();
			}

			_context.Products.Remove(product);
			_context.SaveChanges();
			return RedirectToAction("Index");
		}
		// sua san phầm
		public IActionResult Edit(int? id)
		{
			if (id == null || id == 0)
			{
				return NotFound();
			}
			var product = _context.Products.Find(id);
			if (product == null)
			{
				return NotFound();
			}
			return View(product);
		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Edit(Product product)
		{
			if (ModelState.IsValid)
			{
				_context.Products.Update(product);
				_context.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(product);
		}
	}
}
