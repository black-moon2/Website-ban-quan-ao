﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Shop.Models;

namespace Shop.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PostController : Controller
    {
        
        private readonly DataContext _context;
        public PostController(DataContext context)
        {
            _context = context;
        }
		// hien thi danh sach
        public IActionResult Index()
        {
            var mnPost = _context.Posts.OrderBy(p => p.PostID).ToList();
            return View(mnPost);
            
        }
		// tao bai viet
        public IActionResult Create()
        {
            var mnList = (from m in _context.Menus
                          select new SelectListItem()
                          {
                              Text = m.MenuName,
                              Value = m.MenuID.ToString()
                          }).ToList();

            mnList.Insert(0, new SelectListItem()
            {
                Text = "----Select----",
                Value = string.Empty
            });
            ViewBag.mnList = mnList;
            return View();
        }
        [HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Create(Post post)
        {
            if (ModelState.IsValid)
            {
                _context.Add(post);
                _context.SaveChanges();
				return RedirectToAction("Index");
			}
            return View(post);
        }
        // xóa
		public IActionResult Delete(long? id)
		{
			if (id == null || id == 0)
			{
				return NotFound();
			}

			var post = _context.Posts.Find(id);
			if (post == null)
			{
				return NotFound();
			}

			return View(post);
		}
		[HttpPost]
		public IActionResult Delete(long id)
		{
			var delePost = _context.Posts.Find(id);
			if (delePost == null)
			{
				return NotFound();
			}

			_context.Posts.Remove(delePost);
			_context.SaveChanges();
			return RedirectToAction("Index");
		}
		// sửa bài viet
		public IActionResult Edit(long? id)
		{
			if (id == null || id == 0)
			{
				return NotFound();
			}
			var post = _context.Posts.Find(id);
			if (post == null)
			{
				return NotFound();
			}
			var mnList = (from m in _context.Menus
						  select new SelectListItem()
						  {
							  Text = m.MenuName,
							  Value = m.MenuID.ToString(),
						  }).ToList();
			mnList.Insert(0, new SelectListItem()
			{
				Text = "----Select----",
				Value = "0"
			});
			ViewBag.mnList = mnList;
			return View(post);
		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Edit(Post post)
		{
			if (ModelState.IsValid)
			{
				_context.Posts.Update(post);
				_context.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(post);
		}
	}
}
