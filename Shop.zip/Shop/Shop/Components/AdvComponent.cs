﻿using Microsoft.AspNetCore.Mvc;
using Shop.Models;

namespace Shop.Components
{
    [ViewComponent(Name = "Adv")]
    public class AdvComponent : ViewComponent
    {
        private readonly DataContext _context;
        public AdvComponent(DataContext context)
        {
            _context = context;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var listofAdv = (from a in _context.Advs
                              where (a.Type == 1)
                              select a).ToList();

            return await Task.FromResult((IViewComponentResult)View("Default", listofAdv));
        }
    }
}
