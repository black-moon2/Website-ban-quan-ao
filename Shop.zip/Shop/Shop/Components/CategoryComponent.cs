﻿using Microsoft.AspNetCore.Mvc;
using Shop.Models;

namespace Shop.Components
{
    [ViewComponent(Name = "Category")]
    public class CategoryComponent : ViewComponent
    {
        private readonly DataContext _context;
        public CategoryComponent(DataContext context)
        {
            _context = context;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var listofCat = (from c in _context.Categorys
                              
                              orderby c.CategoryID descending
                              select c).ToList();

            return await Task.FromResult((IViewComponentResult)View("Default", listofCat));
        }
    }
}
