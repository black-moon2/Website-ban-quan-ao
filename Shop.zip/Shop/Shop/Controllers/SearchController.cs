﻿using Microsoft.AspNetCore.Mvc;

namespace Shop.Controllers
{
	public class SearchController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
	}
}
